# skeleton
promesas async await
# https://danielsansp.github.io/skeleton/
## Daniel ospina 

![skeleton](https://user-images.githubusercontent.com/91626236/163253840-e1443d77-c919-49ef-9fe8-e335b66991f3.png)
![Captura de pantalla de 2022-04-13 13-59-44](https://user-images.githubusercontent.com/91626236/163253856-4d78ba3c-5ae1-449a-8321-094895619a92.png)
